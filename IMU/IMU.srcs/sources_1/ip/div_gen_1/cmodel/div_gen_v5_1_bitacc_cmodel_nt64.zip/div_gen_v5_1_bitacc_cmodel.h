//  (c) Copyright 2013 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------

#ifndef XIP_DIV_GEN_V5_1_BITACC_CMODEL_H
#define XIP_DIV_GEN_V5_1_BITACC_CMODEL_H

// Common typedefs, constants and functions for use across Xilinx bit-accurate C models
#undef XIP_XILINX_XIP_TARGET
#define XIP_XILINX_XIP_TARGET div_gen_v5_1
#include "xip_common_bitacc_cmodel.h"
#include "xip_mpz_bitacc_cmodel.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DEFINE_XIP_ARRAY(TYPE) //These functions now actually defined within shared library itself; user definition no longer required

/* Core Specific Constants */

//Values for algorithm_type
#define XIP_DIV_GEN_V5_1_ALGO_RADIX2      1
#define XIP_DIV_GEN_V5_1_ALGO_HIGH_RADIX  3
#define XIP_DIV_GEN_V5_1_ALGO_LUTMULT     4

//Values for operand_sign
#define XIP_DIV_GEN_V5_1_OP_UNSIGNED  0
#define XIP_DIV_GEN_V5_1_OP_SIGNED    1

  //Valuse for remainder_type
#define XIP_DIV_GEN_V5_1_REMTYPE_REMAINDER  0
#define XIP_DIV_GEN_V5_1_REMTYPE_FRACTIONAL 1

// div_gen_v5_1 configuration structure
typedef struct
{
  const char *name;       //@- Instance name (arbitrary)
  int algorithm_type;
  int divisor_width;
  int dividend_width;
  int operand_sign;
  int remainder_type;
  int fractional_width;
  int clocks_per_division;
  int debug;
} xip_div_gen_v5_1_config;

// div_gen_v5_1 handle type (opaque to user)
struct _xip_div_gen_v5_1;
typedef struct _xip_div_gen_v5_1 xip_div_gen_v5_1;

//Helpers for creating arrays
XIP_XILINX_XIP_IMPEXP xip_array_uint* xip_div_gen_v5_1_xip_array_uint_alloc(size_t num_samples);
XIP_XILINX_XIP_IMPEXP xip_array_mpz*  xip_div_gen_v5_1_xip_array_mpz_alloc (size_t num_samples);

//Helpers for accessing data
XIP_XILINX_XIP_IMPEXP const xip_status xip_div_gen_v5_1_xip_array_uint_set_data(xip_array_uint* p, const xip_uint  value, size_t sample);
XIP_XILINX_XIP_IMPEXP const xip_status xip_div_gen_v5_1_xip_array_uint_get_data(const xip_array_uint* p, xip_uint* value, size_t sample);
XIP_XILINX_XIP_IMPEXP const xip_status xip_div_gen_v5_1_xip_array_mpz_set_data(xip_array_mpz* p, const xip_mpz  value, size_t sample);
XIP_XILINX_XIP_IMPEXP const xip_status xip_div_gen_v5_1_xip_array_mpz_get_data(const xip_array_mpz* p, xip_mpz* value, size_t sample);

/**
 * Fill in a configuration structure with the core's default values.
 *
 * @param     config     The configuration structure to be populated
 * @returns   Exit code  XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
const xip_status xip_div_gen_v5_1_default_config(xip_div_gen_v5_1_config *config);

/**
 * Get version of model.
 *
 * @returns   String  Textual representation of model version
 */
XIP_XILINX_XIP_IMPEXP
const char* xip_div_gen_v5_1_get_version(void);

/**
 * Create a new instance of the core based on some configuration values.
 *
 * @param     config      Pointer to a xip_div_gen_v5_1_config structure
 * @param     handler     Callback function for errors and warnings (providing a null
 *                        pointer means no messages are output)
 * @param     handle      Optional argument to be passed back to callback function
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_div_gen_v5_1 *xip_div_gen_v5_1_create(
  const xip_div_gen_v5_1_config *config,
  xip_msg_handler handler,
  void        *handle
);

/**
 * Fill a configuration structure with the core's current state
 */
XIP_XILINX_XIP_IMPEXP
const xip_status xip_div_gen_v5_1_get_config(
  xip_div_gen_v5_1        *s,
  xip_div_gen_v5_1_config *config
  );


/**
 * Apply a transaction on the data port.
 *
 * @param     s           Pointer to xip_div_gen_v5_1 state structure
 * @param     req         Pointer to xip_div_gen_v5_1_data_req request structure
 * @param     resp        Pointer to xip_div_gen_v5_1_data_resp response structure
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
const xip_status xip_div_gen_v5_1_data_do
  ( xip_div_gen_v5_1           *s,
    xip_array_mpz *divisor,
    xip_array_mpz *dividend,
    xip_array_mpz *quotient,
    xip_array_mpz *remainder,
    xip_array_uint *div_by_zero,
    xip_uint       number_of_samples
  );

XIP_XILINX_XIP_IMPEXP
const xip_status xip_div_gen_v5_1_data_real_do
  ( xip_div_gen_v5_1           *s,
    xip_array_real *divisor,
    xip_array_real *dividend,
    xip_array_real *quotient,
    xip_array_real *remainder,
    xip_array_uint *div_by_zero,
    xip_uint       number_of_samples
  );

/**
 * Reset an instance of the core.
 * This function is not supported as the core has no 'state' which affects
 * the calculation of subsequent samples, hence nothing to reset.
 */

/**
 * Destroy an instance of the core and free any resources allocated.
 *
 * @param     s           Pointer to xip_div_gen_v5_1 state structure
 * @returns   Exit code   XIP_STATUS_*
 *
 */
XIP_XILINX_XIP_IMPEXP
const xip_status xip_div_gen_v5_1_destroy(xip_div_gen_v5_1 *s);

#ifdef __cplusplus
}
#endif

#endif
